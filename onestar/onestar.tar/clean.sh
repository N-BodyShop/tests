rm onestar.00*
rm *.chk*
rm *.out
rm onestar.log
rm imf.dat

